// substrate-runtime.js — runs inside substrate.html

import { createSubstrate } from "./substrate-glue.js";

let activeSubstrate = null;

// Ensure substrate is booted once
async function ensureSubstrate() {
  if (!activeSubstrate) {
    console.log("[WCO] Booting Substrate OS in substrate-runtime...");
    activeSubstrate = await createSubstrate();

    // Send readiness handshake to background.js
    if (!activeSubstrate._readySignaled) {
      chrome.runtime.sendMessage({ kind: "substrate.ready" });
      activeSubstrate._readySignaled = true;
    }
  }
  return activeSubstrate;
}

// Message channel: background <-> substrate-runtime
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.kind) return;

  switch (msg.kind) {
    case "substrate.init":
      ensureSubstrate().then(() => {
        chrome.runtime.sendMessage({ kind: "substrate.ready" });
        sendResponse({ ok: true });
    });
    return true;



    case "substrate.browserEvent":
      ensureSubstrate().then(sub => {
        sub.ingestBrowserEvent(msg.event);
        sendResponse({ ok: true });
      });
      return true;

    case "substrate.tick":
      ensureSubstrate().then(async sub => {
        const actions = await sub.tick();
        sendResponse({ ok: true, actions });
      });
      return true;

    case "substrate.shutdown":
      if (activeSubstrate) {
        activeSubstrate.shutdown().then(() => {
          activeSubstrate = null;
          sendResponse({ ok: true });
        });
        return true;
      }
      sendResponse({ ok: true });
      return;

    default:
      break;
  }
});
