// gamification.js
// Production-Grade Gamification Axis: Points, streaks, badges, milestones, progression
// Engagement economy with multi-dimensional reward systems and progression tracking

export const version = "1.0.0";

export const metadata = {
  id: "gamification",
  name: "gamification",
  description: "Enterprise-grade gamification with points, streaks, badges, milestones, and reward pools.",
  trust_level: "core"
};

const DEFAULT_SCHEMA = {
  actions: {
    defaultPointValue: 1,
    enableStreaks: true,
    enableMultipliers: true,
    maxActionsPerDay: 1000
  },
  streaks: {
    windowMs: 24 * 60 * 60 * 1000, // 24 hours
    minConsecutive: 2,
    maxStreakLength: 365,
    streakBonus: { enabled: true, factor: 0.1 } // 10% bonus per streak
  },
  badges: {
    rarityLevels: ["common", "rare", "epic", "legendary"],
    maxBadgesPerUser: 100,
    enableRarityBonus: true,
    rarityBonusMultiplier: { common: 1.0, rare: 1.5, epic: 2.0, legendary: 3.0 }
  },
  milestones: {
    enableAutomation: true,
    maxMilestonesPerUser: 50,
    cascadeRewards: true
  },
  rewards: {
    poolSize: 1000000,
    poolAvailable: 1000000,
    maxClaimsPerUser: null,
    enableThrottling: true,
    throttleWindowMs: 3600000 // 1 hour
  },
  progression: {
    enableTiers: true,
    enableLevelSystem: false,
    tierDecay: false,
    decayRatePerDayMs: 0
  }
};

const state = {
  users: new Map(), // userId -> { id, points, badges, streaks, actionHistory, rewards, tiers, metadata, ... }
  actions: new Map(), // actionType -> { name, points, rarity, multipliers, badges, milestones, createdAt }
  badges: new Map(), // badgeId -> { id, name, rarity, description, earnedCount, createdAt }
  milestones: new Map(), // milestoneId -> { id, name, target, metric, reward, badgeId, createdAt }
  rewards: new Map(), // rewardId -> { id, name, cost, type, data, availableCount, claimedCount, createdAt }
  actionHistory: [], // audit trail of all actions
  streakHistory: new Map(), // userId -> [ { actionType, count, lastAt, earnedAt } ]
  tierProgression: new Map(), // userId -> { tier, points, joinedAt, promotedAt }
  rewardClaims: new Map(), // claimId -> { userId, rewardId, claimedAt, claimedBy }
  conflicts: [], // detected conflicts
  metrics: {
    usersCreated: 0,
    actionsTracked: 0,
    pointsAwarded: 0,
    badgesAwarded: 0,
    milestonesReached: 0,
    rewardsClaimed: 0,
    rewardsPoolRemaining: DEFAULT_SCHEMA.rewards.poolAvailable,
    streaksActive: 0,
    conflictsDetected: 0
  },
  schema: {}
};

function generateUserId() {
  return `user_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateActionId() {
  return `action_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateBadgeId() {
  return `badge_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateMilestoneId() {
  return `milestone_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateRewardId() {
  return `reward_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateClaimId() {
  return `claim_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function _ensureUser(userId) {
  if (!state.users.has(userId)) {
    state.users.set(userId, {
      id: userId,
      points: 0,
      badges: new Set(),
      streaks: new Map(), // actionType -> { count, lastAt, startedAt, bonus }
      actionHistory: [],
      actionTotals: new Map(), // actionType -> count
      rewards: [],
      claimedRewards: new Set(),
      tier: "bronze",
      level: 1,
      metadata: {},
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    state.metrics.usersCreated++;
  }
  return state.users.get(userId);
}

function _computeTier(points) {
  if (points >= 100000) return "platinum";
  if (points >= 10000) return "gold";
  if (points >= 1000) return "silver";
  return "bronze";
}

function _checkStreakContinuation(userId, actionType, now) {
  const user = state.users.get(userId);
  if (!user) return { count: 0, continued: false };

  const streak = user.streaks.get(actionType);
  if (!streak) {
    return { count: 0, continued: false };
  }

  const timeSinceLastAction = now - streak.lastAt;
  if (timeSinceLastAction <= state.schema.streaks.windowMs) {
    return { count: streak.count + 1, continued: true };
  }

  return { count: 1, continued: false };
}

function _computeStreakBonus(streakCount) {
  if (!state.schema.streaks.streakBonus.enabled) return 0;
  if (streakCount < state.schema.streaks.minConsecutive) return 0;
  
  const factor = state.schema.streaks.streakBonus.factor;
  return (streakCount - 1) * factor;
}

function _computeRarityBonus(rarity) {
  if (!state.schema.badges.enableRarityBonus) return 1.0;
  return state.schema.badges.rarityBonusMultiplier[rarity] || 1.0;
}

function _auditLog(action, actor, actionType, points, details = {}) {
  state.actionHistory.push({
    id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    action,
    actor,
    actionType,
    points,
    timestamp: Date.now(),
    details
  });

  if (state.actionHistory.length > 10000) {
    state.actionHistory.shift();
  }
}

function _checkMilestones(userId) {
  const user = state.users.get(userId);
  if (!user) return [];

  const awarded = [];

  for (const [milestoneId, milestone] of state.milestones.entries()) {
    // Check if already achieved
    if (user.actionHistory.some(h => h.details.milestoneId === milestoneId)) {
      continue;
    }

    // Check metric
    let metricValue = 0;
    if (milestone.metric === "points") {
      metricValue = user.points;
    } else if (milestone.metric === "badges") {
      metricValue = user.badges.size;
    } else if (milestone.metric === "actions") {
      const actionType = milestone.actionType;
      metricValue = user.actionTotals.get(actionType) || 0;
    }

    if (metricValue >= milestone.target) {
      // Award milestone
      if (milestone.badgeId) {
        user.badges.add(milestone.badgeId);
      }

      if (milestone.reward) {
        user.points += milestone.reward;
        state.metrics.pointsAwarded += milestone.reward;
      }

      user.actionHistory.push({
        type: "milestone_reached",
        milestoneId,
        timestamp: Date.now(),
        value: metricValue
      });

      state.metrics.milestonesReached++;
      awarded.push(milestoneId);

      _auditLog("milestone_reached", userId, milestone.id, milestone.reward || 0, {
        milestoneId,
        metric: milestone.metric,
        target: milestone.target,
        metricValue
      });
    }
  }

  return awarded;
}

export default {
  name: "gamification",

  async init(ctx) {
    console.log("[Gamification] Initializing...");

    // Use substrate-persistent state instead of internal object
    if (!ctx.state.initialized) {
      ctx.state.auditLog = [];
      ctx.state.metrics = {};
      ctx.state.traces = {};
      ctx.state.debugMode = false;
      ctx.state.systemStartTime = Date.now();
      ctx.state.lastHealthCheck = null;
      ctx.state.healthHistory = [];
      ctx.state.schema = DEFAULT_SCHEMA;
      ctx.state.initialized = true;
      await ctx.saveState(ctx.state);
    }

    const api = {
      // ===== Audit Logging =====
      audit: async (entry) => {
        const now = Date.now();
        const id = `audit_${now}_${Math.random().toString(36).substr(2, 6)}`;

        const record = {
          id,
          timestamp: now,
          action: entry.action,
          actor: entry.actor || "system",
          resource: entry.resource,
          status: entry.status || "completed",
          severity: entry.severity || "info",
          metadata: entry.metadata || {}
        };

        ctx.state.auditLog.push(record);

        // Cap log
        if (ctx.state.auditLog.length > ctx.state.schema.audit.maxEntries) {
          ctx.state.auditLog = ctx.state.auditLog.slice(-ctx.state.schema.audit.maxEntries);
        }

        await ctx.saveState(ctx.state);

        // Emit substrate event
        ctx.Events.emit("gamification.audit", record);

        return { success: true, auditId: id };
      },

      // ===== Metrics =====
      recordMetric: async (metricName, value, tags = {}) => {
        if (!ctx.state.metrics[metricName]) {
          ctx.state.metrics[metricName] = {
            samples: [],
            tags: {},
            aggregations: {}
          };
        }

        const metric = ctx.state.metrics[metricName];
        const now = Date.now();

        metric.samples.push({ value: Number(value) || 0, timestamp: now, tags });

        if (metric.samples.length > 10000) {
          metric.samples = metric.samples.slice(-10000);
        }

        const values = metric.samples.map(s => s.value);
        metric.aggregations = {
          count: values.length,
          sum: values.reduce((a, b) => a + b, 0),
          avg: values.reduce((a, b) => a + b, 0) / values.length,
          min: Math.min(...values),
          max: Math.max(...values),
          p50: _computePercentile(values, 50),
          p90: _computePercentile(values, 90),
          p95: _computePercentile(values, 95),
          p99: _computePercentile(values, 99)
        };

        Object.assign(metric.tags, tags);

        await ctx.saveState(ctx.state);

        ctx.Events.emit("gamification.metric", { metricName, value });

        return { success: true };
      },

      // ===== Tracing =====
      startTrace: async () => {
        const traceId = `trace_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        ctx.state.traces[traceId] = {
          id: traceId,
          spans: [],
          startedAt: Date.now(),
          completedAt: null,
          duration: null,
          errors: []
        };

        await ctx.saveState(ctx.state);

        ctx.Events.emit("gamification.trace", { traceId });

        return { traceId };
      },

      addSpan: async (traceId, span) => {
        const trace = ctx.state.traces[traceId];
        if (!trace) return { success: false, reason: "Trace not found" };

        const entry = {
          spanId: span.spanId || `span_${Math.random().toString(36).substr(2, 6)}`,
          parentSpanId: span.parentSpanId || null,
          name: span.name,
          startedAt: span.startedAt || Date.now(),
          endedAt: span.endedAt || Date.now(),
          duration: (span.endedAt || Date.now()) - (span.startedAt || Date.now()),
          status: span.status || "ok",
          error: span.error || null,
          metadata: span.metadata || {}
        };

        trace.spans.push(entry);
        if (entry.error) {
          trace.errors.push({ spanId: entry.spanId, error: entry.error, timestamp: entry.endedAt });
        }

        await ctx.saveState(ctx.state);

        return { success: true, spanId: entry.spanId };
      },

      endTrace: async (traceId) => {
        const trace = ctx.state.traces[traceId];
        if (!trace) return { success: false, reason: "Trace not found" };

        trace.completedAt = Date.now();
        trace.duration = trace.completedAt - trace.startedAt;

        await ctx.saveState(ctx.state);

        return { success: true, duration: trace.duration };
      }
    };

    // Register module under correct name + context
    ctx.Registry.register("gamification", api, ctx);
  },

  async onSignal(type, payload, ctx) {
    // gamification does not react to signals by default
  },

  async onStateChanged({ module, state }, ctx) {
    //  does not react to other modules' state changes
  },

  async onShutdown(ctx) {
    // Clear persistent state on shutdown
    ctx.state.auditLog = [];
    ctx.state.metrics = {};
    ctx.state.traces = {};
    ctx.state.healthHistory = [];
    await ctx.saveState(ctx.state);
  }
};
