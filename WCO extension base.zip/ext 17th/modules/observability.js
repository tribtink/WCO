// observability-axis-full.js
// Production-Grade Observability Axis: Audit logs, metrics, tracing, health
// Complete system transparency with retention policies and diagnostics

export const version = "1.0.0";

export const metadata = {
  id: "observability-axis",
  name: "Observability Axis",
  description: "Enterprise-grade audit logging, metrics, tracing, and system health.",
  trust_level: "core"
};

const DEFAULT_SCHEMA = {
  audit: {
    retentionMs: 90 * 24 * 60 * 60 * 1000, // 90 days
    severityLevels: ["info", "warning", "error", "critical"],
    maxEntries: 100000,
    samplingRate: 1.0 // 100% sampling by default
  },
  metrics: {
    retentionMs: 30 * 24 * 60 * 60 * 1000, // 30 days
    aggregationWindowMs: 60000, // 1 minute
    maxMetrics: 10000,
    percentiles: [50, 90, 95, 99]
  },
  tracing: {
    samplingRate: 0.1, // 10% of traces
    retentionMs: 7 * 24 * 60 * 60 * 1000, // 7 days
    maxTraces: 50000,
    maxSpansPerTrace: 1000
  },
  health: {
    checkIntervalMs: 60000, // 1 minute
    errorThreshold: 0.1 // 10% error rate triggers warning
  }
};

const state = {
  auditLog: [], // comprehensive event log
  metrics: new Map(), // metricName -> { samples: [], aggregations: {} }
  traces: new Map(), // traceId -> { spans: [], startedAt, completedAt, duration, errors }
  debugMode: false,
  systemStartTime: Date.now(),
  lastHealthCheck: null,
  healthHistory: [], // recent health snapshots
  diagnostics: {
    memoryUsage: 0,
    logSize: 0,
    metricsCount: 0,
    traceCount: 0,
    lastUpdate: Date.now()
  },
  schema: {}
};

function generateAuditId() {
  return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function generateTraceId() {
  return `trace_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function _computePercentile(values, percentile) {
  if (!values.length) return 0;
  const sorted = values.slice().sort((a, b) => a - b);
  const index = Math.ceil((percentile / 100) * sorted.length) - 1;
  return sorted[Math.max(0, index)];
}

function _pruneOldRecords(now) {
  // Prune expired audit logs
  state.auditLog = state.auditLog.filter(e => now - e.timestamp < state.schema.audit.retentionMs);
  
  // Prune old traces
  for (const [traceId, trace] of state.traces.entries()) {
    if (now - trace.startedAt > state.schema.tracing.retentionMs) {
      state.traces.delete(traceId);
    }
  }

  // Prune old metric samples
  for (const [metricName, metric] of state.metrics.entries()) {
    metric.samples = metric.samples.filter(s => now - s.timestamp < state.schema.metrics.retentionMs);
    if (metric.samples.length === 0) {
      state.metrics.delete(metricName);
    }
  }
}

function _updateDiagnostics() {
  state.diagnostics.logSize = state.auditLog.length;
  state.diagnostics.metricsCount = state.metrics.size;
  state.diagnostics.traceCount = state.traces.size;
  state.diagnostics.lastUpdate = Date.now();
}

// observability.js — Fully Substrate-Aligned Version

export default {
  name: "observability",

  async init(ctx) {
    console.log("[Observability Axis] Initializing...");

    // Use substrate-persistent state instead of internal object
    if (!ctx.state.initialized) {
      ctx.state.auditLog = [];
      ctx.state.metrics = {};
      ctx.state.traces = {};
      ctx.state.debugMode = false;
      ctx.state.systemStartTime = Date.now();
      ctx.state.lastHealthCheck = null;
      ctx.state.healthHistory = [];
      ctx.state.schema = DEFAULT_SCHEMA;
      ctx.state.initialized = true;
      await ctx.saveState(ctx.state);
    }

    const api = {
      // ===== Audit Logging =====
      audit: async (entry) => {
        const now = Date.now();
        const id = `audit_${now}_${Math.random().toString(36).substr(2, 6)}`;

        const record = {
          id,
          timestamp: now,
          action: entry.action,
          actor: entry.actor || "system",
          resource: entry.resource,
          status: entry.status || "completed",
          severity: entry.severity || "info",
          metadata: entry.metadata || {}
        };

        ctx.state.auditLog.push(record);

        // Cap log
        if (ctx.state.auditLog.length > ctx.state.schema.audit.maxEntries) {
          ctx.state.auditLog = ctx.state.auditLog.slice(-ctx.state.schema.audit.maxEntries);
        }

        await ctx.saveState(ctx.state);

        // Emit substrate event
        ctx.Events.emit("observability.audit", record);

        return { success: true, auditId: id };
      },

      // ===== Metrics =====
      recordMetric: async (metricName, value, tags = {}) => {
        if (!ctx.state.metrics[metricName]) {
          ctx.state.metrics[metricName] = {
            samples: [],
            tags: {},
            aggregations: {}
          };
        }

        const metric = ctx.state.metrics[metricName];
        const now = Date.now();

        metric.samples.push({ value: Number(value) || 0, timestamp: now, tags });

        if (metric.samples.length > 10000) {
          metric.samples = metric.samples.slice(-10000);
        }

        const values = metric.samples.map(s => s.value);
        metric.aggregations = {
          count: values.length,
          sum: values.reduce((a, b) => a + b, 0),
          avg: values.reduce((a, b) => a + b, 0) / values.length,
          min: Math.min(...values),
          max: Math.max(...values),
          p50: _computePercentile(values, 50),
          p90: _computePercentile(values, 90),
          p95: _computePercentile(values, 95),
          p99: _computePercentile(values, 99)
        };

        Object.assign(metric.tags, tags);

        await ctx.saveState(ctx.state);

        ctx.Events.emit("observability.metric", { metricName, value });

        return { success: true };
      },

      // ===== Tracing =====
      startTrace: async () => {
        const traceId = `trace_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        ctx.state.traces[traceId] = {
          id: traceId,
          spans: [],
          startedAt: Date.now(),
          completedAt: null,
          duration: null,
          errors: []
        };

        await ctx.saveState(ctx.state);

        ctx.Events.emit("observability.trace", { traceId });

        return { traceId };
      },

      addSpan: async (traceId, span) => {
        const trace = ctx.state.traces[traceId];
        if (!trace) return { success: false, reason: "Trace not found" };

        const entry = {
          spanId: span.spanId || `span_${Math.random().toString(36).substr(2, 6)}`,
          parentSpanId: span.parentSpanId || null,
          name: span.name,
          startedAt: span.startedAt || Date.now(),
          endedAt: span.endedAt || Date.now(),
          duration: (span.endedAt || Date.now()) - (span.startedAt || Date.now()),
          status: span.status || "ok",
          error: span.error || null,
          metadata: span.metadata || {}
        };

        trace.spans.push(entry);
        if (entry.error) {
          trace.errors.push({ spanId: entry.spanId, error: entry.error, timestamp: entry.endedAt });
        }

        await ctx.saveState(ctx.state);

        return { success: true, spanId: entry.spanId };
      },

      endTrace: async (traceId) => {
        const trace = ctx.state.traces[traceId];
        if (!trace) return { success: false, reason: "Trace not found" };

        trace.completedAt = Date.now();
        trace.duration = trace.completedAt - trace.startedAt;

        await ctx.saveState(ctx.state);

        return { success: true, duration: trace.duration };
      }
    };

    // Register module under correct name + context
    ctx.Registry.register("observability", api, ctx);
  },

  async onSignal(type, payload, ctx) {
    // Observability does not react to signals by default
  },

  async onStateChanged({ module, state }, ctx) {
    // Observability does not react to other modules' state changes
  },

  async onShutdown(ctx) {
    // Clear persistent state on shutdown
    ctx.state.auditLog = [];
    ctx.state.metrics = {};
    ctx.state.traces = {};
    ctx.state.healthHistory = [];
    await ctx.saveState(ctx.state);
  }
};
