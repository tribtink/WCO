// modules/governance/governance-node.js
//
// WCO Governance Module v0.1
// Provides: proposals, votes, tallies, governance objects,
// governance actions, UI hooks, and preset loading.

import governancePresets from "../../governance-node-presets.json" assert { type: "json" };

export default {
  name: "governance",
  version: "0.1",

  init(ctx) {
    ctx.log("[Governance] init");

    // ------------------------------------------------------------
    // 1. Load governance presets (local_council, assembly, etc.)
    // ------------------------------------------------------------
    ctx.Governance = {
      presets: governancePresets.presets,
      proposals: new Map(), // proposalId -> proposal object
      votes: new Map(),     // proposalId -> array of votes
    };

    ctx.log("[Governance] Loaded presets:", Object.keys(ctx.Governance.presets));

    // ------------------------------------------------------------
    // 2. Create a governance proposal
    // ------------------------------------------------------------
    ctx.actions.createProposal = async ({ title, body, preset = "local_council" }) => {
      const id = crypto.randomUUID();

      const proposal = {
        id,
        type: "governance_proposal",
        timestamp: Date.now(),
        preset,
        payload: { title, body },
        status: "open"
      };

      ctx.Governance.proposals.set(id, proposal);
      ctx.emit("object", proposal);

      ctx.log("[Governance] Created proposal:", id);
      return proposal;
    };

    // ------------------------------------------------------------
    // 3. Cast a vote
    // ------------------------------------------------------------
    ctx.actions.castVote = async ({ proposalId, voterId, choice }) => {
      if (!ctx.Governance.proposals.has(proposalId)) {
        throw new Error("Proposal not found");
      }

      const vote = {
        id: crypto.randomUUID(),
        type: "governance_vote",
        timestamp: Date.now(),
        proposalId,
        voterId,
        choice // "yes" | "no" | "abstain"
      };

      if (!ctx.Governance.votes.has(proposalId)) {
        ctx.Governance.votes.set(proposalId, []);
      }

      ctx.Governance.votes.get(proposalId).push(vote);
      ctx.emit("object", vote);

      ctx.log("[Governance] Vote cast:", vote.id);
      return vote;
    };

    // ------------------------------------------------------------
    // 4. Tally votes
    // ------------------------------------------------------------
    ctx.actions.tallyVotes = ({ proposalId }) => {
      const votes = ctx.Governance.votes.get(proposalId) || [];

      const tally = {
        yes: votes.filter(v => v.choice === "yes").length,
        no: votes.filter(v => v.choice === "no").length,
        abstain: votes.filter(v => v.choice === "abstain").length
      };

      ctx.log("[Governance] Tally:", proposalId, tally);
      return tally;
    };

    // ------------------------------------------------------------
    // 5. Close a proposal
    // ------------------------------------------------------------
    ctx.actions.closeProposal = ({ proposalId }) => {
      const proposal = ctx.Governance.proposals.get(proposalId);
      if (!proposal) throw new Error("Proposal not found");

      proposal.status = "closed";
      ctx.emit("object", proposal);

      ctx.log("[Governance] Closed proposal:", proposalId);
      return proposal;
    };

    // ------------------------------------------------------------
    // 6. UI Integration
    // ------------------------------------------------------------
    ctx.ui = {
      pages: [
        {
          id: "governance-home",
          title: "Governance",
          html: "pages/governance-home.html"
        }
      ],
      buttons: [
        {
          id: "gov-create",
          label: "Create Proposal",
          action: "createProposal"
        },
        {
          id: "gov-tally",
          label: "Tally Votes",
          action: "tallyVotes"
        }
      ]
    };

    ctx.log("[Governance] Ready.");
  }
};
