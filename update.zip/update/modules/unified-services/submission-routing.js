// submission-routing.js

import { Transport } from "./transport.js";

export async function routeSubmission(submission, directoryEntry) {
  const recipient = directoryEntry.payload.transport;
  return Transport.send(submission, recipient);
}

export async function routeToAllVolunteers(submission, directory) {
  for (const entry of directory) {
    await routeSubmission(submission, entry);
  }
}
