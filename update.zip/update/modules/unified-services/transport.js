// transport.js
//
// Minimal transport layer for WCO Substrate v0
// Local-first, optional remote send, directory-driven routing.

export const Transport = {
  async send(submission, recipient) {
    switch (recipient.type) {
      case "http":
        return sendViaHttp(submission, recipient.endpoint);

      case "infinityfree":
        return sendViaInfinityFree(submission);

      case "local":
      default:
        // Local-only: nothing to send
        return true;
    }
  }
};

// --- HTTP Transport ---------------------------------------------

async function sendViaHttp(submission, endpoint) {
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(submission)
    });
    return res.ok;
  } catch (err) {
    console.warn("HTTP transport failed:", err);
    return false;
  }
}

// --- InfinityFree Stub ------------------------------------------

const INFINITYFREE_STUB_URL = "https://YOUR-INFINITYFREE-ENDPOINT.com/store.php";
// Replace with your actual endpoint later.

async function sendViaInfinityFree(submission) {
  try {
    const res = await fetch(INFINITYFREE_STUB_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(submission)
    });
    return res.ok;
  } catch (err) {
    console.warn("InfinityFree transport failed:", err);
    return false;
  }
}
