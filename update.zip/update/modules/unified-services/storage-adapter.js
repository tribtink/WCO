// storage-adapter.js

export const StorageAdapter = {
  async saveSubmission(submission) {
    const key = `submission:${submission.id}`;
    await chrome.storage.local.set({ [key]: submission });
    return true;
  },

  async getSubmission(id) {
    const key = `submission:${id}`;
    const result = await chrome.storage.local.get(key);
    return result[key] || null;
  },

  async listSubmissions() {
    const all = await chrome.storage.local.get(null);
    return Object.values(all).filter(v => v?.type === "submission");
  },

  async searchSubmissions(query) {
    const all = await this.listSubmissions();
    const q = query.toLowerCase();
    return all.filter(s =>
      JSON.stringify(s).toLowerCase().includes(q)
    );
  }
};
