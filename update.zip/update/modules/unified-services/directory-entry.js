// directory-entry.js

export function createDirectoryEntry({ id, type, endpoint }) {
  return {
    id: crypto.randomUUID(),
    type: "directory_entry",
    timestamp: Date.now(),
    payload: {
      targetId: id,
      targetType: type, // "node" or "witness"
      transport: {
        type: "http",     // or "infinityfree"
        endpoint: endpoint
      }
    }
  };
}
