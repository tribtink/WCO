// modules/smorgasbord.js
//
// WCO Smorgasbord Module v0.1
// Demonstrates: submissions, routing, directory entries,
// storage, civic objects, actions, UI hooks, and physics signals.

import { createDirectoryEntry } from "../directory-entry.js";
import { routeSubmission } from "../submission-routing.js";

export default {
  name: "smorgasbord",
  version: "0.1",

  init(ctx) {
    ctx.log("[Smorgasbord] init");

    // ---------------------------------------------
    // 1. Example: Create a civic submission
    // ---------------------------------------------
    ctx.actions.createDemoSubmission = async () => {
      const submission = {
        id: crypto.randomUUID(),
        type: "submission",
        timestamp: Date.now(),
        payload: {
          title: "Hello from Smorgasbord",
          body: "This is a demo submission created by the module.",
          tags: ["demo", "smorgasbord"]
        }
      };

      await ctx.Storage.saveSubmission(submission);
      ctx.log("[Smorgasbord] Saved submission:", submission.id);

      return submission;
    };

    // ---------------------------------------------
    // 2. Example: Create a directory entry
    // ---------------------------------------------
    ctx.actions.createDemoDirectoryEntry = () => {
      const entry = createDirectoryEntry({
        id: "demo-node",
        type: "node",
        endpoint: "https://example.com/receive"
      });

      ctx.log("[Smorgasbord] Created directory entry:", entry.id);
      return entry;
    };

    // ---------------------------------------------
    // 3. Example: Route a submission
    // ---------------------------------------------
    ctx.actions.routeDemoSubmission = async () => {
      const submission = await ctx.actions.createDemoSubmission();
      const entry = ctx.actions.createDemoDirectoryEntry();

      const result = await routeSubmission(submission, entry);
      ctx.log("[Smorgasbord] Routed submission:", result);

      return result;
    };

    // ---------------------------------------------
    // 4. Example: Emit a civic object into physics
    // ---------------------------------------------
    ctx.actions.emitDemoObject = () => {
      const obj = {
        id: crypto.randomUUID(),
        type: "demo_object",
        payload: { message: "Physics hello!" }
      };

      ctx.emit("object", obj);
      ctx.log("[Smorgasbord] Emitted object:", obj.id);

      return obj;
    };

    // ---------------------------------------------
    // 5. Example: React to physics ticks
    // ---------------------------------------------
    ctx.on("tick", (t) => {
      if (t % 60 === 0) {
        ctx.log(`[Smorgasbord] Tick heartbeat: ${t}`);
      }
    });

    // ---------------------------------------------
    // 6. Example: Provide UI pages to popup
    // ---------------------------------------------
    ctx.ui = {
      pages: [
        {
          id: "smorgasbord-home",
          title: "Smorgasbord",
          html: "pages/smorgasbord-home.html"
        }
      ],
      buttons: [
        {
          id: "smorgasbord-create",
          label: "Create Demo Submission",
          action: "createDemoSubmission"
        },
        {
          id: "smorgasbord-route",
          label: "Route Demo Submission",
          action: "routeDemoSubmission"
        },
        {
          id: "smorgasbord-emit",
          label: "Emit Demo Object",
          action: "emitDemoObject"
        }
      ]
    };

    ctx.log("[Smorgasbord] Ready.");
  }
};
