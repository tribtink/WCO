// modules/submissions.js
//
// Civic Submission Service v0.1
//
// Responsibilities:
// - create submissions
// - list submissions
// - search submissions
// - add comments
// - remain storage-agnostic
//
// Storage is provided through ctx.Storage
//

export default {
  name: "submissions",

  async init(ctx) {
    console.log("[submissions] init");

    if (!ctx.state.initialized) {
      ctx.state.stats = {
        submissions: 0,
        comments: 0
      };

      ctx.state.initialized = true;
      await ctx.saveState(ctx.state);
    }
  },

  async onSignal(type, payload, ctx) {

    switch (type) {

      case "submission.create":
        await createSubmission(ctx, payload);
        break;

      case "submission.comment":
        await addComment(ctx, payload);
        break;

      default:
        break;
    }
  },

  async onShutdown(ctx) {
    console.log("[submissions] shutdown");
  }
};

//
// ------------------------------------------------------------------
// Submission API
// ------------------------------------------------------------------
//

async function createSubmission(ctx, payload) {

  const submission = {
    id: payload.id || createId("sub"),

    title: payload.title || "Untitled",

    body: payload.body || "",

    type: payload.type || "submission",

    tags: Array.isArray(payload.tags)
      ? payload.tags
      : [],

    createdAt: new Date().toISOString(),

    createdBy: payload.createdBy || "anonymous",

    comments: []
  };

  await ctx.Storage.saveSubmission(submission);

  ctx.state.stats.submissions += 1;
  await ctx.saveState(ctx.state);

  ctx.Events.emit(
    "submission.created",
    submission
  );

  return submission;
}

async function addComment(ctx, payload) {

  const submission =
    await ctx.Storage.getSubmission(
      payload.submissionId
    );

  if (!submission) {
    throw new Error(
      `Submission not found: ${payload.submissionId}`
    );
  }

  const comment = {
    id: createId("comment"),

    submissionId: submission.id,

    body: payload.body || "",

    createdAt: new Date().toISOString(),

    createdBy: payload.createdBy || "anonymous"
  };

  submission.comments.push(comment);

  await ctx.Storage.saveSubmission(
    submission
  );

  ctx.state.stats.comments += 1;
  await ctx.saveState(ctx.state);

  ctx.Events.emit(
    "submission.commented",
    {
      submissionId: submission.id,
      comment
    }
  );

  return comment;
}

//
// ------------------------------------------------------------------
// Public Service Helpers
// ------------------------------------------------------------------
//

export async function getSubmission(
  storage,
  id
) {
  return storage.getSubmission(id);
}

export async function listSubmissions(
  storage
) {
  return storage.listSubmissions();
}

export async function searchSubmissions(
  storage,
  query
) {
  return storage.searchSubmissions(query);
}

//
// ------------------------------------------------------------------
// Utility
// ------------------------------------------------------------------
//

function createId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}