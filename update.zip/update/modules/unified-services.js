// modules/unified-services.js
//
// WCO Civic Services Bootstrap v0.1
// Exposes submissions, routing, directory, storage, and transport
// to all modules via ctx.

import { StorageAdapter } from "./unified-services/storage-adapter.js";
import { createDirectoryEntry } from "./unified-services/directory-entry.js";
import { routeSubmission, routeToAllVolunteers } from "./unified-services/submission-routing.js";
import { Transport } from "./unified-services/transport.js";

export default {
  name: "bootstrap",
  version: "0.1",

  init(ctx) {
    ctx.log("[Bootstrap] Initializing civic services…");

    // ------------------------------------------------------------
    // 1. Storage
    // ------------------------------------------------------------
    ctx.Storage = StorageAdapter;

    // ------------------------------------------------------------
    // 2. Directory
    // ------------------------------------------------------------
    ctx.Directory = {
      createEntry: createDirectoryEntry
    };

    // ------------------------------------------------------------
    // 3. Routing
    // ------------------------------------------------------------
    ctx.Routing = {
      routeSubmission,
      routeToAllVolunteers
    };

    // ------------------------------------------------------------
    // 4. Transport
    // ------------------------------------------------------------
    ctx.Transport = Transport;

    // ------------------------------------------------------------
    // 5. Health check
    // ------------------------------------------------------------
    ctx.log("[Bootstrap] Civic services ready.");
  }
};
