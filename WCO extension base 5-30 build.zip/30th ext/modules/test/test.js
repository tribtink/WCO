// modules/test/test.js
// Minimal test module to verify node + witness creation

export default {
  name: "test-module",

  async init(ctx) {
    ctx.log("[test-module] Initializing…");

    // --- Create Witness ----------------------------------------------------
    const witness = ctx.witness.createFromPreset("restrictive");

    ctx.log("[test-module] Created witness:", witness);

    // --- Create Node -------------------------------------------------------
    const node = ctx.node.createFromPreset("restrictive");

    ctx.log("[test-module] Created node:", node);

    // --- Expose simple debug API ------------------------------------------
    ctx.exports = {
      getNode() {
        return node;
      },

      getWitness() {
        return witness;
      }
    };

    ctx.log("[test-module] Ready.");
  }
};