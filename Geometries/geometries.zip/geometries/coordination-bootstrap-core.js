import { Substrate, applyDomainSpec } from "./substrate.js";
import coordinationSpec from "./coordinationSpec.js";

const s = new Substrate({ dt: 0.1 });
applyDomainSpec(s, coordinationSpec);

s.run(100);

console.log(s.state.list());
console.log(s.regions.activeRegions(s.state).map(r => r.id));
