// coordinationSpec.js
// Minimal declarative domain spec for the coordination geometry

export default {
  id: "coordination",

  // ---------- VARIABLES ----------
  variables: {
    T:     { initial: 0.5, label: "Trust" },
    C:     { initial: 0.5, label: "Containment" },
    E:     { initial: 0.5, label: "EpistemicQuality" },
    G:     { initial: 0.5, label: "Grievance" },
    P:     { initial: 0.5, label: "PowerAsymmetry" },
    kappa: { initial: 0.5, label: "Context" },

    // Derived variables (optional but useful)
    CC:  { initial: 0.5, label: "CoordinationCost" },
    MP:  { initial: 0.5, label: "MisalignmentPressure" },
    BP:  { initial: 0.5, label: "BoundaryPermeability" },
    ID:  { initial: 0.5, label: "InstitutionalDrift" },
    CAE: { initial: 0.5, label: "CollectiveActionEfficiency" },
    S:   { initial: 0.5, label: "Stability" }
  },

  // ---------- DYNAMICS ----------
  dynamics: [
    {
      id: "trust_update",
      order: 1,
      inputs: ["T", "E", "C", "G"],
      output: "T",
      rule: "T + dt*(0.45*E + 0.35*C - 0.55*G - 0.25*(T-0.5))"
    },
    {
      id: "grievance_update",
      order: 1,
      inputs: ["G", "T", "P"],
      output: "G",
      rule: "G + dt*(0.6*(1-T) + 0.45*P - 0.35*G)"
    },
    {
      id: "epistemics_update",
      order: 1,
      inputs: ["E", "kappa", "BP"],
      output: "E",
      rule: "E + dt*(0.4*kappa - 0.5*BP - 0.3*(E-0.5))"
    },
    {
      id: "containment_update",
      order: 1,
      inputs: ["C", "ID", "G"],
      output: "C",
      rule: "C + dt*(-0.4*ID - 0.3*G + 0.2*(1-C))"
    },
    {
      id: "power_asymmetry_update",
      order: 1,
      inputs: ["P", "C"],
      output: "P",
      rule: "P + dt*(0.3*(1-C) - 0.2*P)"
    },

    // Derived variables
    {
      id: "coordination_cost_update",
      order: 2,
      inputs: ["T", "E", "C"],
      output: "CC",
      rule: "1 - (0.4*T + 0.3*E + 0.3*C)"
    },
    {
      id: "misalignment_pressure_update",
      order: 2,
      inputs: ["G", "P", "E"],
      output: "MP",
      rule: "0.5*G + 0.4*P + 0.2*(1-E)"
    },
    {
      id: "stability_update",
      order: 3,
      inputs: ["T", "C", "G", "MP"],
      output: "S",
      rule: "0.4*T + 0.4*C - 0.3*G - 0.3*MP"
    }
  ],

  // ---------- REGIONS ----------
  regions: {
    stable_peace:     "T>0.75 && C>0.7 && G<0.25",
    cold_peace:       "T>0.55 && C>0.5 && G<0.45",
    hybrid_conflict:  "T>0.35 && T<0.65 && G>0.35 && G<0.65",
    escalation_basin: "T<0.45 && C<0.45 && G>0.45 && G<0.7",
    hot_war:          "T<0.3 && C<0.35 && G>0.7",
    fragmentation:    "S<0.25 && MP>0.7",
    reconciliation:   "T>0.45 && G<0.45 && C>0.45 && MP<0.45"
  },

  // ---------- TRANSFORMS ----------
  transforms: {
    conflict_risk:          "0.6*G + 0.5*MP + 0.4*(1-C) + 0.3*(1-T)",
    coordination_stability: "S",
    trajectory_curvature:   "0.5*Math.abs(T-G) + 0.5*Math.abs(C-MP)",
    containment_integrity:  "C - 0.5*ID",
    epistemic_collapse:     "0.6*(1-E) + 0.4*BP"
  }
};
